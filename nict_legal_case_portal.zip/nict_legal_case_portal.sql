CREATE DATABASE  IF NOT EXISTS `nict_legal_case_portal` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `nict_legal_case_portal`;
-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: nict_legal_case_portal
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `case_history`
--

DROP TABLE IF EXISTS `case_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_history` (
  `sno` int NOT NULL AUTO_INCREMENT,
  `cs_id` int DEFAULT NULL,
  `new_chs` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`sno`),
  KEY `cs_id_idx` (`cs_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_history`
--

LOCK TABLES `case_history` WRITE;
/*!40000 ALTER TABLE `case_history` DISABLE KEYS */;
INSERT INTO `case_history` VALUES (2,5,'2024-06-23'),(3,5,'2024-06-27'),(4,5,'2024-06-26'),(5,5,'2024-06-28');
/*!40000 ALTER TABLE `case_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `legal_case`
--

DROP TABLE IF EXISTS `legal_case`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `legal_case` (
  `cs_id` int NOT NULL AUTO_INCREMENT,
  `uniqueID` varchar(45) DEFAULT NULL,
  `kopid` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `bank` varchar(45) DEFAULT NULL,
  `place` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `date_of_fraud` date DEFAULT NULL,
  `nature_of_fraud` varchar(45) DEFAULT NULL,
  `noc` varchar(45) DEFAULT NULL,
  `amount_involved` varchar(45) DEFAULT NULL,
  `ac` varchar(45) DEFAULT NULL,
  `amount_settled_by_csp` varchar(45) DEFAULT NULL,
  `amount_hold_by_bank` varchar(45) DEFAULT NULL,
  `amount_settled_by_nict` varchar(45) DEFAULT NULL,
  `amout_received_by_csp` varchar(45) CHARACTER SET armscii8 COLLATE armscii8_general_ci DEFAULT NULL,
  `hold_amout_received_by_bank` varchar(45) CHARACTER SET armscii8 COLLATE armscii8_general_ci DEFAULT NULL,
  `fir_status` varchar(45) DEFAULT NULL,
  `crystallization_done` varchar(45) DEFAULT NULL,
  `case_status` varchar(45) DEFAULT NULL,
  `date_of_ccommitee` varchar(45) DEFAULT NULL,
  `chs` date DEFAULT NULL,
  `crystallization_remarks` varchar(2000) DEFAULT NULL,
  `remarks` text,
  `photo` varchar(45) DEFAULT NULL,
  `contact_person` varchar(45) DEFAULT NULL,
  `contact_person_s` varchar(45) DEFAULT NULL,
  `contact_person_t` varchar(45) DEFAULT NULL,
  `location` varchar(45) DEFAULT NULL,
  `mobile` varchar(45) DEFAULT NULL,
  `designation` varchar(45) DEFAULT NULL,
  `new_documents` varchar(45) DEFAULT NULL,
  `court_type` varchar(45) DEFAULT NULL,
  `case_number` varchar(45) DEFAULT NULL,
  `party_case` varchar(45) DEFAULT NULL,
  `new_chs` datetime DEFAULT NULL,
  PRIMARY KEY (`cs_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `legal_case`
--

LOCK TABLES `legal_case` WRITE;
/*!40000 ALTER TABLE `legal_case` DISABLE KEYS */;
/*!40000 ALTER TABLE `legal_case` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nature_of_fraud`
--

DROP TABLE IF EXISTS `nature_of_fraud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nature_of_fraud` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nature_of_fraudcol` varchar(45) DEFAULT NULL,
  `create` datetime DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nature_of_fraud`
--

LOCK TABLES `nature_of_fraud` WRITE;
/*!40000 ALTER TABLE `nature_of_fraud` DISABLE KEYS */;
/*!40000 ALTER TABLE `nature_of_fraud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operator_table`
--

DROP TABLE IF EXISTS `operator_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operator_table` (
  `id` int NOT NULL AUTO_INCREMENT,
  `full_name` varchar(45) DEFAULT NULL,
  `father_name` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `village` varchar(45) DEFAULT NULL,
  `tehsil` varchar(45) DEFAULT NULL,
  `district` varchar(45) DEFAULT NULL,
  `division` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operator_table`
--

LOCK TABLES `operator_table` WRITE;
/*!40000 ALTER TABLE `operator_table` DISABLE KEYS */;
INSERT INTO `operator_table` VALUES (1,'rajesh','mebb','gbg','fdg','fdgdf','dfg','fgf','Assam');
/*!40000 ALTER TABLE `operator_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `other_fraud_case`
--

DROP TABLE IF EXISTS `other_fraud_case`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `other_fraud_case` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uniqueID` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `bank` varchar(45) DEFAULT NULL,
  `place` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `legalnotice` varchar(45) DEFAULT NULL,
  `date_of_notice` varchar(45) DEFAULT NULL,
  `amount_involved` varchar(45) DEFAULT NULL,
  `amount_settled` varchar(45) DEFAULT NULL,
  `legal_notice_reply` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `other_fraud_case`
--

LOCK TABLES `other_fraud_case` WRITE;
/*!40000 ALTER TABLE `other_fraud_case` DISABLE KEYS */;
INSERT INTO `other_fraud_case` VALUES (28,'77851','rajesh mekchand','State Bank of India','Indore- UJJAIN','Madhya Pradesh','HO-Holiday Calender.pdf','2024-11-20','15000','yes','yes');
/*!40000 ALTER TABLE `other_fraud_case` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `other_fraud_login`
--

DROP TABLE IF EXISTS `other_fraud_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `other_fraud_login` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `mobileno` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `other_fraud_login`
--

LOCK TABLES `other_fraud_login` WRITE;
/*!40000 ALTER TABLE `other_fraud_login` DISABLE KEYS */;
INSERT INTO `other_fraud_login` VALUES (1,'Rajesh','7898709566');
/*!40000 ALTER TABLE `other_fraud_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `register`
--

DROP TABLE IF EXISTS `register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `register`
--

LOCK TABLES `register` WRITE;
/*!40000 ALTER TABLE `register` DISABLE KEYS */;
INSERT INTO `register` VALUES (1,'NICT','1234');
/*!40000 ALTER TABLE `register` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sdp_code`
--

DROP TABLE IF EXISTS `sdp_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sdp_code` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sdp_code` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sdp_code`
--

LOCK TABLES `sdp_code` WRITE;
/*!40000 ALTER TABLE `sdp_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `sdp_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_sgb`
--

DROP TABLE IF EXISTS `user_sgb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_sgb` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(45) NOT NULL,
  `user_name` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `role` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2249 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_sgb`
--

LOCK TABLES `user_sgb` WRITE;
/*!40000 ALTER TABLE `user_sgb` DISABLE KEYS */;
INSERT INTO `user_sgb` VALUES (1,'nict_admin','nict_legal','12345','admin'),(2,'nict_user','rajesh','nict%122','user'),(2248,'admin','Admin','nict#2022%','admin');
/*!40000 ALTER TABLE `user_sgb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usercreate`
--

DROP TABLE IF EXISTS `usercreate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usercreate` (
  `id` int NOT NULL AUTO_INCREMENT,
  `loginid` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `officeid` varchar(45) DEFAULT NULL,
  `role` varchar(45) DEFAULT NULL,
  `loginstatus` varchar(45) DEFAULT NULL,
  `createdat` varchar(45) DEFAULT NULL,
  `updatedat` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usercreate`
--

LOCK TABLES `usercreate` WRITE;
/*!40000 ALTER TABLE `usercreate` DISABLE KEYS */;
INSERT INTO `usercreate` VALUES (1,'87530','fd','fghfdgg','mad','Himachal Pradesh','Salary Slips_Rajesh Meckchand.pdf','2024-02-08'),(2,'37515','gdfsgfgfg','fdgfdg','afds','Arunachal Pradesh','Salary Slips_Rajesh Meckchand.pdf','2024-02-06'),(3,'18038','Rajesh','state bank of india','India','Chhattisgarh','Salary Slip.pdf','2024-02-15');
/*!40000 ALTER TABLE `usercreate` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-14 11:42:35
